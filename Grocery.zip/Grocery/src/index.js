const express = require("express")
const cors = require("cors")
const mysql2 = require("mysql2")
const bodyParser = require("body-parser")
const bcrypt = require('bcrypt')

const app = express()
const PORT = 3000

app.use(cors())
app.use(bodyParser.json())
app.set('view engine', 'ejs');
app.use(express.static("public"));
app.use(express.urlencoded({ extended: false }));

// Create the connection to database
const connection = mysql2.createConnection({
    host: 'localhost',
    user: 'root',
    database: 'grocery',
    port: 3306
});

const hashPassowrd = async (password) => {
    //hash the password using bcrypt  

    const saltRounds = 10;//number of salt rounds for bcrypt
    const hashedPassword = await bcrypt.hash(password, saltRounds);
    return hashedPassword
}


app.get('/login', (req, res) => {

    res.render("login")
})

app.get('/', (req, res) => {
    res.render("home")
})

app.get('/signup', (req, res) => {
    res.render("signup")
})

//register user
app.post('/signup', async (req, res) => {
    const data = {
        name: req.body.username,
        password: req.body.password,
        email: req.body.email
    }
    console.log(data)

    connection.query(
        'SELECT * FROM `users` WHERE user_name = ?', [data.name],
        async (err, results, fields) => {
            if (err) { res.send("Some thing went wrong 1!") }
            if (results.length > 0) {
                res.send("Username already exists.Please try a different username");
            } else {

                const newpassword = await hashPassowrd(data.password)

                connection.query(
                    'INSERT INTO `users`(`user_name`, `user_password`, `user_email`) VALUES (?, ?, ?)', [data.name, newpassword, data.email],
                    async (err, results, fields) => {
                        if (err) {
                            console.log(err)
                            res.send("Some thing went wrong 2!")
                        }
                        else res.render("login")
                    }
                )
            }
        }
    )
})

//login user
app.post("/login", async (req, res) => {
    const data = {
        username: req.body.username,
        password: req.body.password
    }

    console.log(data)

    connection.query(
        'SELECT `user_password` FROM `users` WHERE `user_name` = ?', [data.username],
        async (err, results, fields) => {
            if (err) {
                console.log(err)
                res.send("Some thing went wrong!")
            }
            if (results.length > 0) {
                const isPasswordMatch = await bcrypt.compare(req.body.password, results[0].user_password)
                if (isPasswordMatch) {
                    res.send("Succesfully logged!")
                } else {
                    res.send("Password didn't matched!")
                }
            } else {
                res.send("User not found!")
            }
        }
    )
})

app.post('/save-data', (req, res) => {
    connection.query('', (err, results) => {

    })
})


app.listen(PORT, () => {
    console.log(`Listening on http://localhost:${PORT}`)
})